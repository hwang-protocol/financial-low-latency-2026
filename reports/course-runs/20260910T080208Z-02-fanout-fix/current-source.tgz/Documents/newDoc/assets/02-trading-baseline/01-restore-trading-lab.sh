#!/usr/bin/env bash
# Deploy all course trading capabilities once; later chapters only select profiles.
set -Eeuo pipefail
cd /financial-low-latency
REPO_ROOT=/financial-low-latency
SELF="$REPO_ROOT/Documents/newDoc/assets/02-trading-baseline/01-restore-trading-lab.sh"
CTL="$REPO_ROOT/apps/flle-trading-lab/scripts/transport_labctl.sh"
STATE="$REPO_ROOT/Documents/reports/run-state/02-trading-baseline.env"
exec 9>/run/lock/flle-platform-deploy.lock; flock -n 9
# Keep each command's full stream separate from the classroom transcript.
# Explicitly preserve rc: this function is also used in the reuse branch's if.
stage(){
  local name="$1" purpose="$2" log="$3" rc; shift 3
  printf '\n%s / %s\n===== %s =====\n%s\n$' "$(hostname)" "$name" "$name" "$purpose"
  printf ' %q' "$@"; printf '\n完整输出：%s\n' "$log"
  if "$@" >"$log" 2>&1; then rc=0; else rc=$?; fi
  if test "$rc" -ne 0; then
    printf '命令失败，退出码 %s；以下为日志末尾。\n$ tail -n 20 %q\n' "$rc" "$log"
    tail -n 20 "$log"
    return "$rc"
  fi
  # Match actual short receipts, never pretty-print or summarize the state JSON.
  local filter='length($0)<=240 && /(^[A-Za-z][A-Za-z0-9_-]*=|: OK$|^Ran [0-9]+ tests|^OK$|tests passed)/ { rows[++n]=$0 } END { for(i=(n>8?n-7:1);i<=n;i++) print rows[i]; if(!n) print "（没有匹配的短读数；请查完整日志）" }'
  printf '关键结果（最多八行）：\n$ awk %q %q\n' "$filter" "$log"
  awk "$filter" "$log"
  case "$name" in
    '① 查部署条件')
      printf '%s\n' '[条件说明] control_assets / builder_tools / transport_preflight 的 PASS 分别对应管理机材料、.101 编译工具和固定运行包检查。' \
        '[条件说明] exchange_rss_preflight 检查 .1 网卡队列与 CPU 分配是否符合部署前提，不是延迟测量结果。' ;;
    '② 查四条路径的构建来源')
      printf '%s\n' '[来源说明] 文件后的 OK 表示摘要与固定清单一致；source_binary_mapping=PASS 表示源码、构建输入和运行文件的来源关系核验通过。' \
        '[来源说明] fstack_config_contract=PASS 表示 DPDK 路径的 F-Stack 配置符合约定，不表示当前已启动 DPDK。' ;;
    '③ 构建并部署平台')
      printf '%s\n' '[部署说明] .101 编译原生客户端，.111 向 .1/.2 分发运行文件，并准备 .101 网页服务；文件到位不等于进程已启动。' \
        '[部署说明] checkpoint 是回放起点的订单簿检查点；*_sha256 是文件内容摘要，用来核对部署材料，不是性能指标。' ;;
    '④ 启动普通交易配置')
      printf '%s\n' '[启动说明] 本步启动 .1 交易所、.2 行情接收器与交易客户端、.101 网页后台；是否就绪还要看下一步核验。' ;;
    '⑤ 查平台是否就绪'|'查已有平台')
      printf '%s\n' '[进程说明] exchange 是 .1 交易所；trader-auto / trader-manual 是 .2 自动与手动客户端；gateway 是 .101 网页后台。' \
        '[在线说明] ONLINE 表示对应进程在线；pid 是该主机上的进程编号，每次启动可能不同，不是端口号。' \
        '[文件说明] deployed_sha256=PASS 表示所列部署文件摘要核验通过；进程在线与文件一致需要一起看。' \
        '[就绪说明] restore_verdict=TRADING_LAB_READY 表示部署核验通过，不代表已经完成首笔成交或延迟测试。' ;;
  esac
}
if test -s "$STATE.pending"; then
  PENDING_RUN="$(sed -n 's/^RUN_ID=//p' "$STATE.pending")"
  [[ "$PENDING_RUN" =~ ^[A-Za-z0-9._-]+-02-trading-platform$ ]]
  PENDING_OUT="$REPO_ROOT/Documents/reports/course-runs/$PENDING_RUN"
  recovery="$PENDING_OUT/raw/interrupted-cleanup-$(date -u +%Y%m%dT%H%M%S.%NZ)"
  stage '恢复中断部署' '按已保存的 RUN 停止残留进程，成功后才能重新部署。' "$recovery.txt" bash "$CTL" stop "$PENDING_RUN" 2>&1 | tee "$recovery-classroom.txt"
  mv "$STATE.pending" "$PENDING_OUT/aborted-deploy.env"
fi
if test -s "$STATE"; then
  OLD_RUN_ID="$(sed -n 's/^RUN_ID=//p' "$STATE")"
  case "$OLD_RUN_ID" in
    *-02-trading-platform)
      reuse="$REPO_ROOT/Documents/reports/course-runs/$OLD_RUN_ID/raw/reuse-$(date -u +%Y%m%dT%H%M%S.%NZ)"
      if stage '查已有平台' '核对已部署进程与文件；通过后直接复用。' "$reuse.txt" bash "$CTL" verify "$OLD_RUN_ID" 2>&1 | tee "$reuse-classroom.txt"; then
        echo "platform=ALREADY_DEPLOYED run_id=$OLD_RUN_ID"
        printf '%s\n' '[复用说明] 已有平台通过核验，本次沿用该 run_id，不重新编译、部署或启动。'; exit
      fi
      if test "$(bash "$CTL" reuse-state "$OLD_RUN_ID")" != CLEAN; then
        stage '清理快照控制器' '旧平台未通过核验，按原入口清理快照残留。' "$reuse-retire.txt" bash "$CTL" retire-snapshot-controller "$OLD_RUN_ID" 2>&1 | tee "$reuse-retire-classroom.txt"
      fi
      test "$(bash "$CTL" reuse-state "$OLD_RUN_ID")" = CLEAN
      mv "$STATE" "$REPO_ROOT/Documents/reports/course-runs/$OLD_RUN_ID/retired-platform.env"
      ;;
    *-02-trading-baseline)
      legacy="$REPO_ROOT/Documents/reports/course-runs/$OLD_RUN_ID/raw/legacy-stop-$(date -u +%Y%m%dT%H%M%S.%NZ)"
      stage '停止旧版平台' '停止旧版进程，再部署完整平台。' "$legacy.txt" bash apps/flle-trading-lab/scripts/labctl.sh stop "$OLD_RUN_ID" 2>&1 | tee "$legacy-classroom.txt" ;;
    *) echo 'Unrecognized platform state; refusing to overwrite it' >&2; exit 2 ;;
  esac
fi
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-02-trading-platform"
OUT="$REPO_ROOT/Documents/reports/course-runs/$RUN_ID"
mkdir -p "$OUT/raw" "${STATE%/*}"
# Persist identity before the first mutation so interrupted deployment is recoverable.
printf 'RUN_ID=%s\nRUN_DIR=/var/tmp/flle-trading-lab-%s\nWEB_URL=http://10.1.1.101:8088/\nPROFILE=UNIFIED_TRADING_PLATFORM\n' "$RUN_ID" "$RUN_ID" >"$OUT/run.env"
cp "$OUT/run.env" "$STATE.pending"
{
  stage '① 查部署条件' '核对主机、依赖和运行包，确认可以开始部署。' "$OUT/raw/01-preflight.txt" bash "$CTL" preflight "$RUN_ID"
  stage '② 查四条路径的构建来源' '核对固定源码、制品和启动约定，为后续路径比较保留依据。' "$OUT/raw/02-build-contract.txt" bash Documents/newDoc/assets/06-kernel-bypass/four-path-build-contract-audit.sh "$OUT/raw/code-contract"
  stage '③ 构建并部署平台' '在监测 VM 构建，向交易所、Trader 和监测 VM 分发本次运行文件。' "$OUT/raw/03-deploy.txt" bash "$CTL" deploy "$RUN_ID"
  stage '④ 启动普通交易配置' '启动行情、交易客户端和网页，建立本章下单环境。' "$OUT/raw/04-baseline.txt" bash "$CTL" baseline "$RUN_ID"
  stage '⑤ 查平台是否就绪' '[平台] 对: 进程 ONLINE、部署摘要核验通过  证: 当前平台可以交给首单步骤' "$OUT/raw/05-verify.txt" bash "$CTL" verify "$RUN_ID"
} 2>&1 | tee "$OUT/raw/restore.txt"
cp "$OUT/run.env" "$STATE.tmp.$BASHPID"; mv "$STATE.tmp.$BASHPID" "$STATE"
rm -f "$STATE.pending"
sha256sum "$SELF" "$CTL" "$OUT/raw/"*.txt "$OUT/run.env" >"$OUT/SHA256SUMS"
echo "platform=READY profile=SOFTWARE capabilities=Socket,Onload,TCPDirect,DPDK,FeedGuardian"
printf '%s\n' '[配置说明] platform=READY 表示本次部署流程完成；profile=SOFTWARE 表示当前采用普通交易配置。' \
  '[能力说明] capabilities 列出已备齐的收发路径及 FeedGuardian 行情完整性保护能力，不是同时运行的进程清单；DPDK 要切换后才接管数据口。' \
  '[下一步] 打开 http://10.1.1.101:8088/ 查看网页，再按运行①A～①C确认组播；运行②才提交首笔模拟订单。'
echo "evidence=$OUT"
