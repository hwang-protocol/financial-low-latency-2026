#!/usr/bin/env python3
"""Run the actual classroom wrappers against local fixtures; never contact a VM."""
import os
import hashlib
from pathlib import Path
import re
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[4]
ASSETS = Path('Documents/newDoc/assets/02-trading-baseline')
CTL = Path('apps/flle-trading-lab/scripts/transport_labctl.sh')
TRADE = Path('apps/flle-trading-lab/tests/first_trade.py')
AUDIT = Path('Documents/newDoc/assets/06-kernel-bypass/four-path-build-contract-audit.sh')


def put(root, path, text):
    dest = root / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text)
    return dest


def wrapper(root, name):
    return put(root, ASSETS / name, (ROOT / ASSETS / name).read_text()
               .replace('/financial-low-latency', str(root))
               .replace('/run/lock/flle-platform-deploy.lock', str(root / 'deploy.lock')))


class ClassroomOutput(unittest.TestCase):
    def test_deploy_success_and_every_failed_stage(self):
        for failed in ('', 'preflight', 'audit', 'deploy', 'baseline', 'verify'):
            with self.subTest(failed=failed), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                fixture = '''#!/bin/bash
printf '%s\\n' "$1" >>"$CALLS"
printf 'step=%s\\n' "$1"
printf '{"large_state":"fixture-only"}\\n'
if test "$1" = "$FAILED_STAGE"; then echo 'fixture failure' >&2; exit 37; fi
'''
                put(root, CTL, fixture)
                put(root, AUDIT, fixture.replace('"$1"', 'audit'))
                script = wrapper(root, '01-restore-trading-lab.sh')
                result = subprocess.run(['bash', str(script)], capture_output=True, text=True,
                    env=dict(os.environ, CALLS=str(root/'calls'), FAILED_STAGE=failed))
                self.assertEqual(result.returncode, 37 if failed else 0, result.stderr)
                expected = ['preflight', 'audit', 'deploy', 'baseline', 'verify']
                if failed:
                    expected = expected[:expected.index(failed)+1]
                    self.assertIn('fixture failure', result.stdout)
                    self.assertNotIn('platform=READY', result.stdout)
                    self.assertNotIn('[配置说明]', result.stdout)
                    self.assertNotIn('[下一步]', result.stdout)
                else:
                    self.assertNotIn('{"large_state"', result.stdout)
                    self.assertIn('platform=READY', result.stdout)
                    for label in ('条件', '来源', '部署', '启动', '进程', '在线', '文件', '就绪', '配置', '能力'):
                        self.assertIn('[' + label + '说明]', result.stdout)
                    self.assertIn('不是同时运行的进程清单', result.stdout)
                    self.assertIn('运行②才提交首笔模拟订单', result.stdout)
                self.assertEqual((root/'calls').read_text().splitlines(), expected)
                out = next((root/'Documents/reports/course-runs').iterdir())
                raw = out/'raw'
                self.assertIn('large_state', (raw/'01-preflight.txt').read_text())
                self.assertIn('===== ① 查部署条件 =====', (raw/'restore.txt').read_text())
                state = root/'Documents/reports/run-state/02-trading-baseline.env'
                self.assertEqual(state.exists(), not bool(failed))
                self.assertEqual(Path(str(state)+'.pending').exists(), bool(failed))
                if not failed:
                    subprocess.run(['sha256sum', '--quiet', '-c', str(out/'SHA256SUMS')], check=True)
                    # Existing-platform path calls only verify and also hides JSON.
                    again = subprocess.run(['bash', str(script)], capture_output=True, text=True,
                        env=dict(os.environ, CALLS=str(root/'calls'), FAILED_STAGE=''))
                    self.assertEqual(again.returncode, 0, again.stderr)
                    self.assertIn('ALREADY_DEPLOYED', again.stdout)
                    self.assertNotIn('{"large_state"', again.stdout)
                    self.assertIn('[在线说明]', again.stdout)
                    self.assertIn('[复用说明]', again.stdout)
                    self.assertNotIn('[配置说明]', again.stdout)
                    self.assertNotIn('profile=SOFTWARE', again.stdout)
                    self.assertEqual((root/'calls').read_text().splitlines(), expected+['verify'])

    def test_first_trade_keeps_failure_and_does_not_trade_after_bad_gate(self):
        for gate_rc, trade_rc in ((0, 0), (23, 0), (0, 42)):
            with self.subTest(gate_rc=gate_rc, trade_rc=trade_rc), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                put(root, CTL, 'echo "trader-manual=ONLINE"\necho \'{"state":"fixture-only"}\'\nexit "$GATE_RC"\n')
                put(root, TRADE, 'import os\nfrom pathlib import Path\nPath(os.environ["CALLED"]).touch()\nprint("result=fixture-only")\nraise SystemExit(int(os.environ["TRADE_RC"]))\n')
                put(root, Path('Documents/reports/run-state/02-trading-baseline.env'),
                    'RUN_ID=LOCAL-FIXTURE\nWEB_URL=http://unused.invalid/\n')
                script = wrapper(root, '02-first-trade.sh')
                result = subprocess.run(['bash', str(script)], capture_output=True, text=True,
                    env=dict(os.environ, GATE_RC=str(gate_rc), TRADE_RC=str(trade_rc), CALLED=str(root/'called')))
                self.assertEqual(result.returncode, gate_rc or trade_rc, result.stderr)
                self.assertEqual((root/'called').exists(), gate_rc == 0)
                raw = root/'Documents/reports/course-runs/LOCAL-FIXTURE/raw'
                self.assertIn('===== ①', (raw/'first-trade-classroom.txt').read_text())
                self.assertIn('fixture-only', (raw/'verify-before-trade.txt').read_text())
                if not gate_rc:
                    self.assertLess(result.stdout.index('$ python3'), result.stdout.index('result=fixture-only'))
                    self.assertNotIn('{"state"', result.stdout)
                if gate_rc or trade_rc:
                    self.assertNotIn('evidence=', result.stdout)
                else:
                    subprocess.run(['sha256sum', '--quiet', '-c', str(raw.parent/'FIRST_TRADE_SHA256SUMS')], check=True)

    def test_stage_no_matching_fields_is_not_a_business_failure(self):
        source = (ROOT/ASSETS/'01-restore-trading-lab.sh').read_text()
        function = source[source.index('stage(){'):source.index('\nif test -s "$STATE.pending"')]
        with tempfile.TemporaryDirectory() as td:
            result = subprocess.run(['bash', '-Eeuo', 'pipefail', '-c', function +
                '\nstage sample purpose "$1/raw.txt" printf "plain text\\n"', 'test', td], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('没有匹配的短读数', result.stdout)
            self.assertEqual((Path(td)/'raw.txt').read_text(), 'plain text\n')

    def test_runtime_prep_filters_install_logs_and_preserves_errors(self):
        for package_rc, remote_rc in ((0, 0), (19, 0), (0, 23)):
            with self.subTest(package_rc=package_rc, remote_rc=remote_rc), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                bindir = root/'bin'
                bindir.mkdir()
                for name, content in {
                    'scp': 'exit 0',
                    'ssh': 'cat >/dev/null; printf "build noise\\n%.0s" {1..100}; printf "fixture-host / verify\\n===== 查主机名 =====\\nfixture-host\\n"; exit "$REMOTE_RC"',
                }.items():
                    f = put(bindir, Path(name), '#!/bin/bash\n'+content+'\n')
                    f.chmod(0o755)
                put(root, Path('Documents/newDoc/assets/common/install-offline-packages.py'),
                    'import os\nprint("package=fixture-only")\nraise SystemExit(int(os.environ["PACKAGE_RC"]))\n')
                archive = put(root, Path('artifacts/blobs/x2522/onload/v9.0.2/onload-9f330e7-vm-2522-01.tgz'), 'fixture-only')
                script = wrapper(root, '00a-runtime-prep.sh')
                script.write_text(script.read_text()
                    .replace('/run/lock/flle-platform-runtime-prep.lock', str(root/'runtime.lock'))
                    .replace('998d218db3733d85e3732f56790eca963f24deb05c6da4306d4dd9ab0c29d9e2', hashlib.sha256(archive.read_bytes()).hexdigest()))
                result = subprocess.run(['bash', str(script)], capture_output=True, text=True,
                    env=dict(os.environ, PATH=str(bindir)+':'+os.environ['PATH'], PACKAGE_RC=str(package_rc), REMOTE_RC=str(remote_rc)))
                self.assertEqual(result.returncode, package_rc or remote_rc, result.stderr)
                out = next((root/'Documents/reports/course-runs').iterdir())
                self.assertIn('===== 查安装归档 =====', (out/'raw/result.txt').read_text())
                if not package_rc and not remote_rc:
                    self.assertIn('build noise', (out/'raw/10.1.1.1-runtime.txt').read_text())
                    self.assertNotIn('build noise', result.stdout)
                    self.assertIn('===== 查主机名 =====', result.stdout)
                    subprocess.run(['sha256sum', '--quiet', '-c', 'SHA256SUMS'], cwd=out, check=True)
                else:
                    self.assertNotIn('evidence=', result.stdout)

    def test_first_trade_document_is_exact(self):
        chapter = (ROOT/'Documents/newDoc/02-host-native-trading-system-baseline.md').read_text()
        script = (ROOT/ASSETS/'02-first-trade.sh').read_text()
        self.assertIn(script, re.findall(r'```bash\n(.*?)```', chapter, re.S))


if __name__ == '__main__':
    unittest.main()
