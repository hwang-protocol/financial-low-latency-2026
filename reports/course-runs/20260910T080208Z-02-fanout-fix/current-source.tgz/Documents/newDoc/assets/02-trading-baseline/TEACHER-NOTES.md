# 第二部分维护与输出来源

## 本轮顺稿范围

最新输出标签收口：首单结果的 order_id 明确解释为 client_order_id，网页对照也写客户端编号；first_trade.py 的原始打印字段不改。准备 C 格式器与正文统一使用“第 N 条命令”，①A只保留配置/范围两行解释及完整原生命令。本轮只改显示文字，9 项 IGMP 与 5 项课堂输出回归通过；准备 C 示例与新格式器离线读取下表原始 switch.txt 的输出有序逐行一致。没有设备操作，不能把新版标题说成旧终端当时已打印，历史清单不改写。

首单时序图按实际编号来源修正：MANUAL 的 queue_order 分配 UserRefNum 并入队，控制返回 client_order_id；Exchange 接受后另分配 order_reference。图中先标本地分配，再保留返回/发送并行，交易所受理和成交分成两条回报。正文“受理编号”改为客户端编号，说明拒绝分支及拿号不等于受理。依据 trader.cpp 的 allocate_user_ref / queue_order / ORDER 分支、exchange.cpp 的 process_order 路径和已核阅 Nasdaq OUCH 5.0 规范；只改 Mermaid 与解释，不改协议或程序。800px 与 871px 原尺寸渲染目视通过，见 `Documents/design/evidence/chapter02-order-id-clarity-20260910.json`。

评估收口：章尾检查统一为“运行③：复查平台与组播状态”，同步学习目标、Mermaid、任务地图、导航卡和绿卡。正文移除修复/更新/补跑等维护过程措辞，保留正向证据范围；准备 C 仅在风险卡说明一次 running-config 与维护重启恢复，并提示重启后重做本步。EOS 命令用“第 1～9 条”讲解，历史终端圈号保持原样。复查示例只留原始 trader-auto、Dynamic/Et2 与当前健康三行，完整输出仍为下表原件；本轮未修改脚本或重跑设备。原生命令展示和终端打印保留，避免违背用户此前要求。

正文按“准备环境 → 启动系统 → 确认组播 → 首笔模拟交易与只读复查”展开。2026-09-10 经用户批准修复接收缓冲并重部署，完整顺刷已通过；维护 RUN 为 `20260910T043407Z-02-feed-buffer-fix`，平台为 `20260910T043800Z-02-trading-platform`。Nasdaq 案例和协议范围保留在延伸阅读，旧样例与本次新结果的来源分别列在下表。

## 展示输出与页面来源

| 内容 | 原始来源 |
| --- | --- |
| 准备 A 四项检查 | `20260910T033839Z-02-onload-runtime-prep` 的 `raw/10.1.1.2-runtime.txt`；保留版本完整输出、字符设备、驱动归属与数据口地址，仅去除两行版本号的行尾空格及主机名重复查询；六项SHA核验通过 |
| 准备 B 安全模式 | `20260907T143627Z-02-guest-iommu-prep`；两端 N，历史配置并重启约 19 秒 |
| 准备 C 配置与空成员表 | 用户运行 `20260910T040553Z-02-igmp-configure/raw/switch.txt`；修改格式器前七项SHA通过。正文第 4、7～9 条命令的结果由当前格式器离线读取该原始回执产生，保留只有命令回显、没有成员行的结果；“第 N 条命令”标题和末行“成员说明”属于当前展示格式，不冒充当次终端文字。历史 raw/classroom.txt 和清单不改写 |
| 运行 ① 在线检查 | `20260910T043407Z-02-feed-buffer-fix/raw/restore.txt`；外层完整回执包含平台 `20260910T043800Z-02-trading-platform` 的五阶段注释、四项 ONLINE、文件 PASS 及最终平台 READY 提示 |
| 三张网页截图 | `20260829T023952Z-02-trading-baseline` |
| 运行 ①A 完整原生命令 | `20260910T045439Z-02-igmp-join/raw/classroom.txt`；补跑默认参数展开后的打印，复用既有接收器，成员查询通过 |
| 运行 ①C 五包与恢复 | `20260910T044818Z-02-igmp-feed/raw/classroom.txt`；持续回放后再次检查，五包、HEALTHY、恢复 UNICAST 均通过 |
| 首笔交易八行 | `20260910T043800Z-02-trading-platform/raw/first-trade.txt`；BUY AAPL 1，成交 293.87，持仓 +1，RTT 58117 ns |
| 最终复查节选 | `20260910T044832Z-02-readonly-review/raw/classroom.txt`；平台、主机与交换机成员、当前 HEALTHY / OPEN 的原始关键行 |

上述 RUN 原件在 `Documents/reports/course-runs/`。本次不是恢复快照：停止旧平台后依次准备 A/B/C、构建部署、加组、成员、抓包、首单与复查，准备 B 按需重启了两端。脚本仍保存完整日志及摘要；持久摘要见 `Documents/design/evidence/chapter02-feed-gap-fix-20260910.json`。

#### 后续为什么必须复用它

| 后续变量 | 仍然不变的业务基线 | 届时比较什么 |
| --- | --- | --- |
| CPU、内存、队列与亲和性 | 同一 MANUAL 客户端，AUTO 保持独立负载 | 热路径分布与尾部是否变化 |
| eBPF/XDP | 同一真实 ITCH 行情 | 更早观察或筛选后，应用责任怎样变化 |
| OpenOnload/TCPDirect | 同一订单会话与成交闭环 | 缩短内核网络路径后的差异 |
| DPDK/Kernel Bypass | 同一订单协议、下单意图与成交闭环 | 订单路径上的驱动所有权与轮询模型差异 |
| 交换机与组播优化 | 同一 AAPL/NVDA Feed | 转发、复制、排队与恢复行为的差异 |

第二部分只建立**功能控制组**，不拿本章的一次 `order_rtt_ns` 宣布性能。第四部分会先固定测量点、负载、环境和统计口径，再把后续优化与这一应用的普通 Linux profile 做公平 A/B。

### 源代码与恢复入口

完整应用在 [`apps/flle-trading-lab/`](../../../../apps/flle-trading-lab/)；学生不需要先读完几千行代码才能把系统拉起来。先按职责找到入口，第三部分再沿真实报文深入。

| 路径 | 负责什么 | 是否进入热路径 |
| --- | --- | --- |
| `src/exchange.cpp` | 历史回放、行情发布、订单连接、纸面撮合 | 是，C++ |
| `src/feed_receiver.cpp` / `src/feed_ipc.hpp` | 用普通 UDP Socket 统一接收行情，保留整包与接收时间，经 Unix Socket 分发给本机 Trader | 是，C++ |
| `src/trader.cpp` | 同一二进制按 `AUTO/MANUAL` 角色启动为两个进程；各自拥有 Feed、风控、订单 ID 和订单会话 | 是，C++ |
| `src/nasdaq_protocol.hpp` | ITCH/MoldUDP64/OUCH/SoupBinTCP 课程子集编解码 | 是，C++ |
| `src/itch_book.hpp` | 从 ITCH 订单事件维护 AAPL/NVDA 订单簿 | 是，C++ |
| `src/book_checkpoint.cpp` | 从 09:30 前增量生成真实开盘订单簿检查点 | 部署工具 |
| `flle_trading/gateway.py` | 汇总旁路状态，提供 HTTP/SSE 与控制 API | 否，Python |
| `web/` | 浏览器行情、价格走势、盘口、策略、订单与成交界面 | 否，HTML/CSS/JS |
| `scripts/transport_labctl.sh` | 完整平台部署、普通交易与路径测试配置切换、验签和停止 | 编排工具 |
| `tests/first_trade.py` | 走和网页同一条 `/api/order` 接口，提交一笔手动 IOC，再按订单 ID 核对回执 | 课堂下单脚本 |
| `tests/latency_regression.py` | 在固定条件下采样 120 笔手动 IOC，断言订单 RTT 的 P99 低于 10 ms 上限 | 工程回归工具 |

行情制品已保存在管理机，恢复脚本核验后直接分发。完整源码目录和制品重建方法见 [Trading Lab 说明](../../../../apps/flle-trading-lab/README.md)；课堂上先看各服务是否启动，再核对首笔成交。

## 本地配套资产

运行①的 `stage` 在原始关键行之后另行打印字段说明，不修改命令原始日志；五阶段解释材料/工具、构建来源、部署产物、启动与核验，复用分支也解释在线和文件字段。末尾区分当前SOFTWARE配置、已备齐能力与DPDK按需接管；5组课堂输出回归覆盖各阶段失败、复用和原始日志保留。Unix Socket解释对照 `feed_receiver.cpp`、`feed_ipc.hpp`、`trader.cpp` 的AF_UNIX调用，放在同机行情分发首次使用处。

运行①A对照 `control-host.sh` 的 start_feed_receiver 和 `feed_receiver.cpp` 的 udp/main。正文直接列完整二进制路径及全部相关参数，不以 .sh 包装命令或变量替代原生命令；23 行入口同步打印当次路径和展开的默认值，标为等效启动配置，不声称控制器实际显式传入了所有默认值。direct 映射为 --multicast-receiver 1，C++ 调用 setsockopt/IP_ADD_MEMBERSHIP；不把进程复用检查当作实际收包证明。

| 资产 | 用途 |
| --- | --- |
| `assets/02-trading-baseline/00a-runtime-prep.sh` | 准备 A：一次备齐运行依赖 |
| `assets/02-trading-baseline/00b-iommu-prep.sh` | 准备 B：按需配置并重启以启用网卡隔离 |
| `assets/02-trading-baseline/test-iommu-prep.py` | 教师离线回归：隔离组、双端准备与失败回滚 |
| `assets/02-trading-baseline/test-preparation-contracts.py` | 教师离线回归：重复准备、失败留证与首单就绪条件 |
| `assets/02-trading-baseline/01-restore-trading-lab.sh` | 运行 ① 完整学生入口；仓库根执行 `bash Documents/newDoc/assets/02-trading-baseline/01-restore-trading-lab.sh` |
| `assets/02-trading-baseline/02-first-trade.sh` | 运行 ② 完整学生入口；仓库根执行 `bash Documents/newDoc/assets/02-trading-baseline/02-first-trade.sh` |
| `apps/flle-trading-lab/scripts/labctl.sh` | 预置应用的安全编排、验签与精确停止 |
| `apps/flle-trading-lab/tests/first_trade.py` | 按订单 ID 核对在线 IOC、持仓增量与统一记录 |
| `images/course-visuals/02-diagrams/02-trading-lab-runtime.svg` | 运行架构、热路径与观察路径 |
| `images/course-visuals/02-diagrams/02-nasdaq-multicast-routing.svg` | Nasdaq 真实组播端点、PIM 建树与接入层复制的机制示意 |
| `images/course-visuals/02-diagrams/02-build-start-trade.svg` | 构建、启动与首笔交易流程 |
| `images/course-visuals/02-diagrams/02-ui-replay-book-order.png` | 网页：回放、盘口与手工下单 |
| `images/course-visuals/02-diagrams/02-ui-trend-latency.png` | 网页：价格走势、延时基线与策略 |
| `images/course-visuals/02-diagrams/02-ui-blotter-path.png` | 网页：统一交易记录与系统路径 |
| `images/course-visuals/02-diagrams/02-ui-first-trade-receipt.png` | 网页：运行 ② 同一笔手动单回执 |


## 本地 IGMP 从第三部分前移

用户要求先准备好组播环境，再下首单。第二部分新增准备 C（配置）、运行①A（加组/主机查询）、①B（交换机表）、①C（实际收包）。第三部分删重复配置讲解及执行，三模式脚本改为 show + VLAN20/成员检查。早期本地回放曾使用 `20260908T124946Z-03-market-paths` 的历史材料；现在①A～①C已有完整实跑，正文五包已更新为上表新来源，准备 C 仍保留用户原空表，不用后续有成员的结果覆盖它。

### 原第三部分来源

删除的旧讲解保存在[快照开刷前的第三部分原文](../../../reports/course-runs/20260908T122503Z-00-10-snapshot-replay/source-before/03-live-trading-traffic-and-protocols.md)。此处只保留来源，不再复制旧绿色卡片。

## 复评后的验证边界

完整九项顺刷通过，持续观察 519.97 秒到 next_expected=1002609，末次健康检查为 1036667 / HEALTHY / OPEN；两路 UDP Socket drops 和系统 RcvbufErrors 为 0。默认逐 Socket 请求 4 MiB，实际 rb=8388608；全局 rmem_default/rmem_max 仍为 212992。构建器运行 193 项测试，184 通过、9 项因缺 Documents 跳过；这 9 项已在 .111 单独通过。IGMP 9 项替身回归覆盖预存 GAP、健康等待失败及恢复失败；复查仅 GET 当前状态，不再重复首单文本。桌面和移动网页只读检查通过，能看到本单回执。

这不是孤立变量性能 A/B，也不是完整 6.5 小时回放验收。旧运行为何没有触发，缺少当时负载/调度证据，仍未确定。课堂配置/成员展示使用 `--display`，第三部分自动前置检查继续使用默认严格模式；不扩展为第三部分或全课程新版本通过。
