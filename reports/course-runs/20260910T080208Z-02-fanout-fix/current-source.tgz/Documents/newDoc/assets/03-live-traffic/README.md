# 第三部分：行情与订单报文资产

## 课堂入口与输出

三个 Bash 入口与正文绿卡逐字一致，分别为 39/41/36 行。抓包、模式切换、下单和检查仍由 Bash 编排；`classroom-output.py` 只负责 DEC-195 分段说明、回读已有 pcap/文本、给解析器的 verdict 附加边界说明，不调用 SSH、HTTP 或订单程序。①②共用 `market-mode.sh`，统一打印并执行有超时的模式请求、回读与失败恢复，避免两份恢复逻辑漂移。

新输出统一写到 `Documents/reports/course-runs/$CHAPTER_RUN_ID/`：`raw/` 保留原始抓包、命令结果及不加注释的解码；`classroom.txt` 另存完整终端打印；`SHA256SUMS` 校验源码与原件，`CLASSROOM_SHA256SUMS` 在终端记录关闭后登记课堂日志和原清单。既有报告根目录下的历史 03 目录不搬移、不改写。

显示工具是课堂预置辅助工具：输入为动作名、脚本已经确定的参数与原件路径，输出为注释、命令和原文字段；不生成 RUN、不恢复业务、不增加业务断言。`tcpdump -r` 只读已有文件。显示失败会明确提示，原抓包、HTTP、解析器的退出行为仍由 Bash 的原门槛决定。

## IGMP 操作前移与退役文件

配置、客户端订阅、交换机成员和实际收包已作为第二部分正式绿卡，先于首单执行。运行②只读取第二部分 `igmp-show.plan`，调用 `inspect-igmp.py --members --display` 展示 VLAN20/Et2 原文，由学员判断；底层 CLI 错误和后续协议解析检查保持。

**`market-igmp-enable.plan` 已退役，仅为历史追溯保留，现役入口不引用。** 重启交换机后按第二部分准备 C 恢复配置，不执行此旧计划。

## 本地验证与已知限制

`python3 Documents/newDoc/assets/03-live-traffic/test-classroom-output.py` 使用三组历史原件，在 `/tmp/ch03-output-check/` 的隔离副本中替代所有 SSH/curl/下单命令；运行 17 个正常、失败和异常成员显示场景，不连接设备、不创建正式 RUN。fixture 的解释器固定为 `/usr/bin/python3`，防止 PATH 中的同名测试工具递归调用。

①②恢复请求失败或实际模式不符返回125，恢复成功保留原业务退出码。③传入 `--first-trade`，按实际成交的 `order_id` 选择 O/A/E，不把前一次被拒的尝试当成本次成交。`test-order-selection.py` 的三项回归覆盖先拒后成、目标编号不存在及目标无成交回报。PIT-20260910-13/14 的正常路径已在当前平台三卡顺刷验证；故障分支使用隔离替身验证，没有故意破坏实机 HTTP 服务。最新来源见教师说明。
