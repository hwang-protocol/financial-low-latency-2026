// One ordinary Socket network receiver; local clients subscribe via AF_UNIX.
#include "common.hpp"
#include "feed_ipc.hpp"
#include <sys/stat.h>
#include <poll.h>
#include <csignal>
#include <array>
#include <iostream>
#include <vector>

namespace {
volatile std::sig_atomic_t stopped = 0;
void stop(int) { stopped = 1; }
std::string arg(int argc, char **argv, const std::string &key,
                const std::string &fallback) {
  for (int i = 1; i + 1 < argc; ++i) if (argv[i] == key) return argv[i + 1];
  return fallback;
}
int receive_buffer(int fd) {
  int bytes = 0;
  socklen_t size = sizeof(bytes);
  if (::getsockopt(fd, SOL_SOCKET, SO_RCVBUF, &bytes, &size))
    throw std::runtime_error("feed UDP receive buffer query failed");
  return bytes;
}
int udp(const std::string &ip, int port, int buffer_bytes, const std::string &group = {}) {
  const int fd = ::socket(AF_INET, SOCK_DGRAM | SOCK_CLOEXEC, 0);
  if (fd < 0) throw std::runtime_error("feed UDP socket failed");
  if (::setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &buffer_bytes, sizeof(buffer_bytes)))
    throw std::runtime_error("feed UDP receive buffer setup failed");
  // Linux doubles SO_RCVBUF and otherwise silently caps it at rmem_max.
  if (receive_buffer(fd) < 2 * buffer_bytes &&
      ::setsockopt(fd, SOL_SOCKET, SO_RCVBUFFORCE, &buffer_bytes, sizeof(buffer_bytes)))
    throw std::runtime_error("feed UDP receive buffer capped: CAP_NET_ADMIN or a sufficient net.core.rmem_max is required");
  if (receive_buffer(fd) < 2 * buffer_bytes)
    throw std::runtime_error("feed UDP receive buffer is below the requested size");
  sockaddr_in addr{}; addr.sin_family = AF_INET; addr.sin_port = htons(port);
  if (::inet_pton(AF_INET, group.empty() ? ip.c_str() : group.c_str(), &addr.sin_addr) != 1)
    throw std::runtime_error("invalid feed IP");
  // Deliberately no SO_REUSEPORT: exactly one network owner in this namespace.
  if (::bind(fd, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) < 0)
    throw std::runtime_error("feed UDP bind failed: " + std::string(std::strerror(errno)));
  if (!group.empty()) {
    ip_mreq membership{};
    ::inet_pton(AF_INET, group.c_str(), &membership.imr_multiaddr);
    ::inet_pton(AF_INET, ip.c_str(), &membership.imr_interface);
    if (::setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &membership, sizeof(membership)))
      throw std::runtime_error("feed multicast join failed");
  }
  return fd;
}
}

int main(int argc, char **argv) {
  const auto path = arg(argc, argv, "--socket", "feed.sock");
  bool owns_path = false;
  std::uint64_t received = 0, delivered = 0, slow_drops = 0;
  try {
    ::signal(SIGINT, stop); ::signal(SIGTERM, stop); ::signal(SIGPIPE, SIG_IGN);
    const auto ip = arg(argc, argv, "--data-ip", "20.1.1.2");
    const auto group = arg(argc, argv, "--multicast-group", "233.74.125.32");
    const int unicast_port = std::stoi(arg(argc, argv, "--unicast-port", "42121"));
    const int multicast_port = std::stoi(arg(argc, argv, "--multicast-port", "31032"));
    const bool multicast = arg(argc, argv, "--multicast-receiver", "1") == "1";
    const int buffer_bytes = std::stoi(arg(argc, argv, "--receive-buffer-bytes", "4194304"));
    if (buffer_bytes < 65536 || buffer_bytes > 64 * 1024 * 1024)
      throw std::runtime_error("invalid feed receive buffer size");
    if (unicast_port < 1 || unicast_port > 65535 || multicast_port < 1 || multicast_port > 65535)
      throw std::runtime_error("invalid feed port");
    const int unicast = udp(ip, unicast_port, buffer_bytes);
    const int multi = multicast ? udp(ip, multicast_port, buffer_bytes, group) : -1;
    const int server = ::socket(AF_UNIX, SOCK_SEQPACKET | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
    const auto address = flle::feed_address(path);
    if (server < 0 || ::bind(server, reinterpret_cast<const sockaddr *>(&address), sizeof(address)))
      throw std::runtime_error("local feed socket already exists or cannot bind");
    owns_path = true;
    if (::chmod(path.c_str(), 0600) || ::listen(server, 16))
      throw std::runtime_error("local feed listen failed");
    std::cout << "feed_receiver=READY unicast=" << ip << ':' << unicast_port
              << " multicast=" << (multicast ? group : "DISABLED") << ':' << multicast_port
              << " ipc=" << path << " unicast_rcvbuf=" << receive_buffer(unicast)
              << " multicast_rcvbuf=" << (multicast ? receive_buffer(multi) : 0) << std::endl;
    std::vector<int> clients;
    std::array<pollfd, 3> fds{{{server, POLLIN, 0}, {unicast, POLLIN, 0}, {multi, POLLIN, 0}}};
    std::array<std::uint8_t, 65536 + flle::feed_header_size> packet{};
    while (!stopped) {
      if (::poll(fds.data(), fds.size(), 200) < 0) {
        if (errno == EINTR) continue;
        throw std::runtime_error("feed poll failed");
      }
      if (fds[0].revents & POLLIN) {
        for (;;) {
          const int client = ::accept4(server, nullptr, nullptr, SOCK_NONBLOCK | SOCK_CLOEXEC);
          if (client < 0) break;
          if (clients.size() >= 32) ::close(client); else clients.push_back(client);
        }
      }
      for (unsigned i = 1; i <= 2; ++i) {
        if (!(fds[i].revents & POLLIN)) continue;
        const auto size = ::recv(fds[i].fd, packet.data() + flle::feed_header_size,
                                 packet.size() - flle::feed_header_size, MSG_TRUNC);
        if (size < 0 || static_cast<std::size_t>(size) > packet.size() - flle::feed_header_size) continue;
        ++received;
        flle::feed_header(packet.data(), i - 1, flle::monotonic_ns());
        const auto total = static_cast<std::size_t>(size) + flle::feed_header_size;
        for (auto it = clients.begin(); it != clients.end();) {
          const auto sent = ::send(*it, packet.data(), total, MSG_DONTWAIT | MSG_NOSIGNAL);
          if (sent == static_cast<ssize_t>(total)) { ++delivered; ++it; }
          else if (sent < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            // A slow consumer may lose packets; existing sequence-gap handling
            // detects loss. It cannot stall delivery to the other consumers.
            ++slow_drops; ++it;
          } else { ::close(*it); it = clients.erase(it); }
        }
      }
    }
    for (const int client : clients) ::close(client);
    ::close(server); ::close(unicast); if (multi >= 0) ::close(multi);
    ::unlink(path.c_str()); owns_path = false;
    std::cout << "feed_receiver=STOPPED received=" << received << " delivered=" << delivered
              << " slow_consumer_drops=" << slow_drops << std::endl;
    return 0;
  } catch (const std::exception &e) {
    if (owns_path) ::unlink(path.c_str());
    std::cerr << "feed_receiver: " << e.what() << '\n';
    return 1;
  }
}
