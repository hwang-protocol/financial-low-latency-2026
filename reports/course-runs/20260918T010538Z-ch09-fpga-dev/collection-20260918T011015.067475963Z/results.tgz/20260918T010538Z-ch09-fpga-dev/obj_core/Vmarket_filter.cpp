// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vmarket_filter.h for the primary calling header

#include "Vmarket_filter.h"
#include "Vmarket_filter__Syms.h"

//==========

void Vmarket_filter::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vmarket_filter::eval\n"); );
    Vmarket_filter__Syms* __restrict vlSymsp = this->__VlSymsp;  // Setup global symbol table
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
#ifdef VL_DEBUG
    // Debug assertions
    _eval_debug_assertions();
#endif  // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/opt/flle-ch09-dev/20260918T010538Z-ch09-fpga-dev/src/market_filter.sv", 3, "",
                "Verilated model didn't converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

void Vmarket_filter::_eval_initial_loop(Vmarket_filter__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        _eval_settle(vlSymsp);
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/opt/flle-ch09-dev/20260918T010538Z-ch09-fpga-dev/src/market_filter.sv", 3, "",
                "Verilated model didn't DC converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

VL_INLINE_OPT void Vmarket_filter::_sequent__TOP__1(Vmarket_filter__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_sequent__TOP__1\n"); );
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    IData/*31:0*/ __Vdly__remaining_drops;
    // Body
    __Vdly__remaining_drops = vlTOPp->remaining_drops;
    if (vlTOPp->rst_n) {
        if ((1U & (~ (IData)(vlTOPp->cfg_load_valid)))) {
            if (((IData)(vlTOPp->s_valid) & (IData)(vlTOPp->s_ready))) {
                vlTOPp->m_mold_seq = vlTOPp->s_mold_seq;
            }
        }
    } else {
        vlTOPp->m_mold_seq = 0ULL;
    }
    if (vlTOPp->rst_n) {
        vlTOPp->drop_valid = 0U;
        if ((1U & (~ (IData)(vlTOPp->cfg_load_valid)))) {
            if (((IData)(vlTOPp->s_valid) & (IData)(vlTOPp->s_ready))) {
                if (vlTOPp->market_filter__DOT__hit) {
                    vlTOPp->drop_valid = 1U;
                }
            }
        }
    } else {
        vlTOPp->drop_valid = 0U;
    }
    if (vlTOPp->rst_n) {
        vlTOPp->m_valid = 0U;
        if ((1U & (~ (IData)(vlTOPp->cfg_load_valid)))) {
            if (((IData)(vlTOPp->s_valid) & (IData)(vlTOPp->s_ready))) {
                if ((1U & (~ (IData)(vlTOPp->market_filter__DOT__hit)))) {
                    vlTOPp->m_valid = 1U;
                }
            }
        }
    } else {
        vlTOPp->m_valid = 0U;
    }
    if (vlTOPp->rst_n) {
        if ((1U & (~ (IData)(vlTOPp->cfg_load_valid)))) {
            if (((IData)(vlTOPp->s_valid) & (IData)(vlTOPp->s_ready))) {
                if (vlTOPp->market_filter__DOT__hit) {
                    vlTOPp->drop_count = ((IData)(1U) 
                                          + vlTOPp->drop_count);
                }
            }
        }
    } else {
        vlTOPp->drop_count = 0U;
    }
    if (vlTOPp->rst_n) {
        if ((1U & (~ (IData)(vlTOPp->cfg_load_valid)))) {
            if (((IData)(vlTOPp->s_valid) & (IData)(vlTOPp->s_ready))) {
                if ((1U & (~ (IData)(vlTOPp->market_filter__DOT__hit)))) {
                    vlTOPp->pass_count = ((IData)(1U) 
                                          + vlTOPp->pass_count);
                }
            }
        }
    } else {
        vlTOPp->pass_count = 0U;
    }
    if (vlTOPp->rst_n) {
        if (vlTOPp->cfg_load_valid) {
            __Vdly__remaining_drops = vlTOPp->cfg_load_drops;
        } else {
            if (((IData)(vlTOPp->s_valid) & (IData)(vlTOPp->s_ready))) {
                if (vlTOPp->market_filter__DOT__hit) {
                    __Vdly__remaining_drops = (vlTOPp->remaining_drops 
                                               - (IData)(1U));
                }
            }
        }
    } else {
        __Vdly__remaining_drops = 0U;
    }
    vlTOPp->remaining_drops = __Vdly__remaining_drops;
}

VL_INLINE_OPT void Vmarket_filter::_settle__TOP__2(Vmarket_filter__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_settle__TOP__2\n"); );
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->s_ready = (1U & (~ (IData)(vlTOPp->cfg_load_valid)));
    vlTOPp->market_filter__DOT__hit = ((((((IData)(vlTOPp->s_valid) 
                                           & (IData)(vlTOPp->s_ready)) 
                                          & (0x41U 
                                             == (0xffU 
                                                 & (vlTOPp->s_itch[8U] 
                                                    >> 0x18U)))) 
                                         & ((0xffffU 
                                             & (vlTOPp->s_itch[8U] 
                                                >> 8U)) 
                                            == (IData)(vlTOPp->cfg_locate))) 
                                        & ((((QData)((IData)(
                                                             vlTOPp->s_itch[2U])) 
                                             << 0x20U) 
                                            | (QData)((IData)(
                                                              vlTOPp->s_itch[1U]))) 
                                           == vlTOPp->cfg_stock)) 
                                       & (0U != vlTOPp->remaining_drops));
}

void Vmarket_filter::_eval(Vmarket_filter__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_eval\n"); );
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (((IData)(vlTOPp->clk) & (~ (IData)(vlTOPp->__Vclklast__TOP__clk)))) {
        vlTOPp->_sequent__TOP__1(vlSymsp);
    }
    vlTOPp->_settle__TOP__2(vlSymsp);
    // Final
    vlTOPp->__Vclklast__TOP__clk = vlTOPp->clk;
}

VL_INLINE_OPT QData Vmarket_filter::_change_request(Vmarket_filter__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_change_request\n"); );
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    return (vlTOPp->_change_request_1(vlSymsp));
}

VL_INLINE_OPT QData Vmarket_filter::_change_request_1(Vmarket_filter__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_change_request_1\n"); );
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vmarket_filter::_eval_debug_assertions() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((clk & 0xfeU))) {
        Verilated::overWidthError("clk");}
    if (VL_UNLIKELY((rst_n & 0xfeU))) {
        Verilated::overWidthError("rst_n");}
    if (VL_UNLIKELY((s_valid & 0xfeU))) {
        Verilated::overWidthError("s_valid");}
    if (VL_UNLIKELY((cfg_load_valid & 0xfeU))) {
        Verilated::overWidthError("cfg_load_valid");}
}
#endif  // VL_DEBUG
