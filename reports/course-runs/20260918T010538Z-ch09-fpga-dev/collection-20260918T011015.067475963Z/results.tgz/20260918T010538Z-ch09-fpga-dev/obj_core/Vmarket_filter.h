// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Primary design header
//
// This header should be included by all source files instantiating the design.
// The class here is then constructed to instantiate the design.
// See the Verilator manual for examples.

#ifndef _VMARKET_FILTER_H_
#define _VMARKET_FILTER_H_  // guard

#include "verilated.h"

//==========

class Vmarket_filter__Syms;

//----------

VL_MODULE(Vmarket_filter) {
  public:
    
    // PORTS
    // The application code writes and reads these signals to
    // propagate new values into/out from the Verilated model.
    VL_IN8(clk,0,0);
    VL_IN8(rst_n,0,0);
    VL_IN8(s_valid,0,0);
    VL_OUT8(s_ready,0,0);
    VL_IN8(cfg_load_valid,0,0);
    VL_OUT8(m_valid,0,0);
    VL_OUT8(drop_valid,0,0);
    VL_IN16(cfg_locate,15,0);
    VL_INW(s_itch,287,0,9);
    VL_IN(cfg_load_drops,31,0);
    VL_OUT(remaining_drops,31,0);
    VL_OUT(pass_count,31,0);
    VL_OUT(drop_count,31,0);
    VL_IN64(s_mold_seq,63,0);
    VL_IN64(cfg_stock,63,0);
    VL_OUT64(m_mold_seq,63,0);
    
    // LOCAL SIGNALS
    // Internals; generally not touched by application code
    CData/*0:0*/ market_filter__DOT__hit;
    
    // LOCAL VARIABLES
    // Internals; generally not touched by application code
    CData/*0:0*/ __Vclklast__TOP__clk;
    
    // INTERNAL VARIABLES
    // Internals; generally not touched by application code
    Vmarket_filter__Syms* __VlSymsp;  // Symbol table
    
    // CONSTRUCTORS
  private:
    VL_UNCOPYABLE(Vmarket_filter);  ///< Copying not allowed
  public:
    /// Construct the model; called by application code
    /// The special name  may be used to make a wrapper with a
    /// single model invisible with respect to DPI scope names.
    Vmarket_filter(const char* name = "TOP");
    /// Destroy the model; called (often implicitly) by application code
    ~Vmarket_filter();
    
    // API METHODS
    /// Evaluate the model.  Application must call when inputs change.
    void eval() { eval_step(); }
    /// Evaluate when calling multiple units/models per time step.
    void eval_step();
    /// Evaluate at end of a timestep for tracing, when using eval_step().
    /// Application must call after all eval() and before time changes.
    void eval_end_step() {}
    /// Simulation complete, run final blocks.  Application must call on completion.
    void final();
    
    // INTERNAL METHODS
  private:
    static void _eval_initial_loop(Vmarket_filter__Syms* __restrict vlSymsp);
  public:
    void __Vconfigure(Vmarket_filter__Syms* symsp, bool first);
  private:
    static QData _change_request(Vmarket_filter__Syms* __restrict vlSymsp);
    static QData _change_request_1(Vmarket_filter__Syms* __restrict vlSymsp);
    void _ctor_var_reset() VL_ATTR_COLD;
  public:
    static void _eval(Vmarket_filter__Syms* __restrict vlSymsp);
  private:
#ifdef VL_DEBUG
    void _eval_debug_assertions();
#endif  // VL_DEBUG
  public:
    static void _eval_initial(Vmarket_filter__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _eval_settle(Vmarket_filter__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _sequent__TOP__1(Vmarket_filter__Syms* __restrict vlSymsp);
    static void _settle__TOP__2(Vmarket_filter__Syms* __restrict vlSymsp);
} VL_ATTR_ALIGNED(VL_CACHE_LINE_BYTES);

//----------


#endif  // guard
