// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vmarket_filter.h for the primary calling header

#include "Vmarket_filter.h"
#include "Vmarket_filter__Syms.h"

//==========

VL_CTOR_IMP(Vmarket_filter) {
    Vmarket_filter__Syms* __restrict vlSymsp = __VlSymsp = new Vmarket_filter__Syms(this, name());
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Reset internal values
    
    // Reset structure values
    _ctor_var_reset();
}

void Vmarket_filter::__Vconfigure(Vmarket_filter__Syms* vlSymsp, bool first) {
    if (false && first) {}  // Prevent unused
    this->__VlSymsp = vlSymsp;
    if (false && this->__VlSymsp) {}  // Prevent unused
    Verilated::timeunit(-9);
    Verilated::timeprecision(-12);
}

Vmarket_filter::~Vmarket_filter() {
    VL_DO_CLEAR(delete __VlSymsp, __VlSymsp = NULL);
}

void Vmarket_filter::_eval_initial(Vmarket_filter__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_eval_initial\n"); );
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vclklast__TOP__clk = vlTOPp->clk;
}

void Vmarket_filter::final() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::final\n"); );
    // Variables
    Vmarket_filter__Syms* __restrict vlSymsp = this->__VlSymsp;
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
}

void Vmarket_filter::_eval_settle(Vmarket_filter__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_eval_settle\n"); );
    Vmarket_filter* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_settle__TOP__2(vlSymsp);
}

void Vmarket_filter::_ctor_var_reset() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vmarket_filter::_ctor_var_reset\n"); );
    // Body
    clk = VL_RAND_RESET_I(1);
    rst_n = VL_RAND_RESET_I(1);
    s_valid = VL_RAND_RESET_I(1);
    s_ready = VL_RAND_RESET_I(1);
    VL_RAND_RESET_W(288, s_itch);
    s_mold_seq = VL_RAND_RESET_Q(64);
    cfg_locate = VL_RAND_RESET_I(16);
    cfg_stock = VL_RAND_RESET_Q(64);
    cfg_load_drops = VL_RAND_RESET_I(32);
    cfg_load_valid = VL_RAND_RESET_I(1);
    m_valid = VL_RAND_RESET_I(1);
    drop_valid = VL_RAND_RESET_I(1);
    m_mold_seq = VL_RAND_RESET_Q(64);
    remaining_drops = VL_RAND_RESET_I(32);
    pass_count = VL_RAND_RESET_I(32);
    drop_count = VL_RAND_RESET_I(32);
    market_filter__DOT__hit = VL_RAND_RESET_I(1);
}
