# U250 手动加入课程源码

先把本文件夹完整放到 `C:\QYT-FPGA\flle-src`。五份 `.sv` 全在这一个目录，本包不包含自动执行脚本。官方原始工程已由用户创建，下一步在 Vivado GUI 中亲手加入这些代码。

## 当前一步：加入三个设计模块

1. 左侧 **Add Sources → Add or create design sources → Next → Add Files**。
2. 在本目录选 `market_filter.sv`、`flle_rx_filter.sv`、`flle_rx_port.sv` 三个文件。
3. 取消 **Copy sources into project**，直接引用本目录的固定源码。若有自动扫描选项可保持默认。
4. 截图保留文件列表、路径和 Copy sources 选项，随后点 **Finish**。
5. 设计顶层保持 `open_nic_shell`。此时还未接上接收路径，不运行综合。

| 文件 | 用途 | 加入方式 |
| --- | --- | --- |
| market_filter.sv | 行情消息判决、一次丢包额度 | 当前加入 Design Sources |
| flle_rx_filter.sv | 整帧适配、流水线校验和 | 当前加入 Design Sources |
| flle_rx_port.sv | 控制寄存器和跨时钟 IP 接线 | 当前加入 Design Sources |
| p2p_250mhz.sv | 将过滤器接入 OpenNIC 收包路径 | 下一步更换工程中的接线文件引用 |
| flle_rx_control_tb.sv | 产生输入并检查行为 | 随后加入 Simulation Sources |

## 后续接线步骤，按GUI逐步完成

在 Design Sources 展开 `open_nic_shell → box_250mhz_inst → p2p_250mhz_inst`，核对原文件来自 `C:/QYT-FPGA/plugin/p2p/p2p_250mhz.sv`。先 **Remove File from Project** 移除这份原接线文件的工程引用，保留磁盘原件；再用 **Add Sources → Add or create design sources** 加入本目录的 `p2p_250mhz.sv`，取消 Copy sources into project。这样全部课程设计源码都引用同一个 flle-src 目录，工程内只保留一个 p2p_250mhz 模块定义。

确认 `p2p_250mhz_inst → … rx_filter_inst → filter_inst → core` 层次已经接入。打开 flle_rx_filter，确认路径来自 flle-src，搜索能看到 `checksum_tree` 和 `CHECKSUM`。

再用 **Add Sources → Add or create simulation sources** 加入本目录 `flle_rx_control_tb.sv`，取消 Copy sources into project，保留 Include all design sources for simulation。仿真顶层选 **flle_rx_port_tb**，设计顶层仍是 **open_nic_shell**。

上述两个顶层用途不同；测试文件名也不等于仿真顶层名。点击 Run Behavioral Simulation 后 Run All，成功时预期：

```text
U250_RX_CONTROL_SIMULATION=PASS cases=11 vendor_cdc=1 hardware=NOT_RUN
```

仿真之后才进入人工综合、实现与报告检查。当前只加入第一组设计文件，逐阶段截图。用户已限定本轮只做一次完整构建；若失败保存真实结果，不继续修改和重试。

## 来源与验证

源码为已有流水线候选的冻结副本，本次仅整理交付位置，没有修改RTL或重新跑测试。五份文件与已核对候选的SHA256逐一一致；之前本地适配器29、控制12（vendor_cdc=0）、扩展适配器102项PASS。Windows真实IP联合仿真、整板时序和实卡仍待新工程验证。

`p2p_250mhz.sv` 是基于OpenNIC固定提交940907fc99fc8d73dbea0028b3a23095a660a42a的课程修改文件，保留上游版权说明，许可证见LICENSE-OpenNIC.txt。其余课程文件的来源和哈希见SOURCE-MANIFEST.json。

AMD关于外部引用与工程内副本的说明：https://docs.amd.com/r/2022.2-English/ug895-vivado-system-level-design-entry/Updating-Local-Source-Files 。本轮直接引用本目录输入，不同时维护工程导入副本。
