#!/usr/bin/env bash
# Remote ownership guard for the real DPDK/F-Stack order client.
# Run only on vm-2522-02 over the 10.1.1.x management network.
set -Eeuo pipefail

BDF=0000:03:00.0
IFACE=ens64np1
ADDR=20.1.1.2/24
GROUP=7
EXPECTED_HOST=vm-2522-02
DEADMAN="${FLLE_DPDK_DEADMAN:-180}"
ROOT_PID=$BASHPID
USER_REF_SLOT_RAW="${FLLE_DPDK_USER_REF_SLOT-}"
USER_REF_BASE_RAW="${FLLE_DPDK_USER_REF_BASE-}"
USER_REF_SPAN_RAW="${FLLE_DPDK_USER_REF_SPAN-}"
UINT32_LIMIT=4294967296
HUGETLBFS=/dev/hugepages

CONFIG="${1:?usage: $0 CONFIG BINARY SESSION_DIR STOP_FILE}"
BINARY="${2:?usage: $0 CONFIG BINARY SESSION_DIR STOP_FILE}"
SESSION_DIR="${3:?usage: $0 CONFIG BINARY SESSION_DIR STOP_FILE}"
STOP_FILE="${4:?usage: $0 CONFIG BINARY SESSION_DIR STOP_FILE}"
RUNTIME_ROOT="$(cd -- "$(dirname -- "$BINARY")/.." && pwd)"
DPDK_DEVBIND="$RUNTIME_ROOT/bin/dpdk-devbind.py"
export LD_LIBRARY_PATH="$RUNTIME_ROOT/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
mkdir -p "$SESSION_DIR"
exec > >(tee "$SESSION_DIR/session.log") 2>&1
rm -f -- "$SESSION_DIR/trader-exit.receipt" \
  "$SESSION_DIR/gate-exit.receipt"

trader_pid=""
trader_exit_status="not_started"
trader_termination="not_started"
trader_cleanup_mode="not_observed"
trader_shutdown_rc="not_observed"
trader_peer_eof="not_observed"
hugetlbfs_mounted_by_wrapper=0
hugetlbfs_dir_created_by_wrapper=0
HUGETLBFS_BASELINE="$(findmnt -rn --mountpoint "$HUGETLBFS" \
  -o FSTYPE,TARGET,SOURCE,OPTIONS 2>/dev/null || true)"
if mountpoint -q "$HUGETLBFS" && [[ "$HUGETLBFS_BASELINE" != hugetlbfs\ * ]]; then
  echo "$HUGETLBFS is an unexpected non-hugetlbfs mount" >&2
  exit 1
fi

record_trader_exit() {
  local tmp="$SESSION_DIR/trader-exit.receipt.tmp.$BASHPID"
  {
    echo "trader_exit_status=$trader_exit_status"
    echo "trader_termination=$trader_termination"
    echo "cleanup_mode=$trader_cleanup_mode"
    echo "shutdown_rc=$trader_shutdown_rc"
    echo "peer_eof=$trader_peer_eof"
  } >"$tmp"
  mv -- "$tmp" "$SESSION_DIR/trader-exit.receipt"
}

wait_for_trader_exit() {
  local request_stop="${1:?request-stop flag is required}" rc escalated=0
  [[ -n "$trader_pid" ]] || return 0
  if [[ "$request_stop" = 1 ]]; then
    trader_termination=SIGINT
    kill -INT "$trader_pid" 2>/dev/null || true
  else
    trader_termination=unexpected
  fi
  for _ in $(seq 1 80); do
    kill -0 "$trader_pid" 2>/dev/null || break
    sleep 0.25
  done
  if kill -0 "$trader_pid" 2>/dev/null; then
    escalated=1
    trader_termination=SIGTERM_TIMEOUT
    kill -TERM "$trader_pid" 2>/dev/null || true
    for _ in $(seq 1 20); do
      kill -0 "$trader_pid" 2>/dev/null || break
      sleep 0.25
    done
  fi
  if kill -0 "$trader_pid" 2>/dev/null; then
    escalated=1
    trader_termination=SIGKILL_TIMEOUT
    kill -KILL "$trader_pid" 2>/dev/null || true
  fi
  if wait "$trader_pid"; then rc=0; else rc=$?; fi
  trader_exit_status=$rc
  trader_pid=""
  record_trader_exit
  if [[ "$escalated" -eq 1 && "$rc" -eq 0 ]]; then return 124; fi
  return "$rc"
}

require_trader_alive() {
  kill -0 "$trader_pid" 2>/dev/null && return 0
  local rc
  if wait_for_trader_exit 0; then rc=0; else rc=$?; fi
  echo "DPDK trader exited before STOP: status=$rc" >&2
  [[ "$rc" -ne 0 ]] || rc=1
  return "$rc"
}

for value_name in USER_REF_SLOT_RAW USER_REF_BASE_RAW USER_REF_SPAN_RAW; do
  value="${!value_name}"
  [[ "$value" =~ ^[0-9]+$ ]] || {
    printf 'invalid unsigned integer: %s=%q\n' "$value_name" "$value" >&2
    exit 2
  }
  [[ "${#value}" -le 10 ]] || {
    printf 'unsigned integer is too large: %s=%q\n' "$value_name" "$value" >&2
    exit 2
  }
done
USER_REF_SLOT=$((10#$USER_REF_SLOT_RAW))
USER_REF_BASE=$((10#$USER_REF_BASE_RAW))
USER_REF_SPAN=$((10#$USER_REF_SPAN_RAW))
(( USER_REF_BASE > 0 && USER_REF_BASE < UINT32_LIMIT )) || {
  echo "user_ref base is outside uint32: $USER_REF_BASE" >&2
  exit 2
}
(( USER_REF_SPAN > 0 && USER_REF_SPAN <= UINT32_LIMIT - USER_REF_BASE )) || {
  printf 'user_ref span crosses uint32 boundary: base=%s span=%s\n' \
    "$USER_REF_BASE" "$USER_REF_SPAN" >&2
  exit 2
}
USER_REF_END_EXCLUSIVE=$((USER_REF_BASE + USER_REF_SPAN))
{
  echo "user_ref_slot=$USER_REF_SLOT"
  echo "user_ref_base=$USER_REF_BASE"
  echo "user_ref_span=$USER_REF_SPAN"
  echo "user_ref_end_exclusive=$USER_REF_END_EXCLUSIVE"
} | tee "$SESSION_DIR/user-ref.receipt"

current_netdev() {
  find "/sys/bus/pci/devices/$BDF/net" -mindepth 1 -maxdepth 1 \
    -printf '%f\n' 2>/dev/null | head -n 1
}

restore() {
  local wrapper_rc="${1:-$?}" cleanup_trader_rc=0 final_rc restore_ok=1
  local driver netdev address hugepages carrier ping_ok vfio_holders
  local hugetlbfs_current
  final_rc="$wrapper_rc"
  [[ "$BASHPID" -eq "$ROOT_PID" ]] || return 0
  set +e
  if [[ -n "$trader_pid" ]]; then
    if wait_for_trader_exit 1; then
      cleanup_trader_rc=0
    else
      cleanup_trader_rc=$?
    fi
    set +e
  fi
  if [[ "$cleanup_trader_rc" -ne 0 && "$final_rc" -eq 0 ]]; then
    final_rc="$cleanup_trader_rc"
  fi
  pkill -f "^${BINARY} " 2>/dev/null || true
  "$DPDK_DEVBIND" --bind=sfc "$BDF" >/dev/null 2>&1 || true
  udevadm settle || true
  current="$(current_netdev)"
  if [[ -n "$current" && "$current" != "$IFACE" ]]; then
    ip link set "$current" down || true
    ip link set "$current" name "$IFACE" || true
  fi
  ip link set "$IFACE" up || true
  ip addr replace "$ADDR" dev "$IFACE" || true
  for _ in $(seq 1 30); do
    [[ "$(cat "/sys/class/net/$IFACE/carrier" 2>/dev/null)" = 1 ]] && break
    sleep 1
  done
  find "$HUGETLBFS" -maxdepth 1 -type f -name 'rtemap_*' -delete \
    2>/dev/null || true
  for _ in $(seq 1 30); do
    sysctl -w vm.nr_hugepages=0 >/dev/null 2>&1 || true
    [[ "$(cat /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages)" = 0 ]] \
      && break
    sleep 1
  done
  if [[ "$hugetlbfs_mounted_by_wrapper" -eq 1 ]]; then
    umount "$HUGETLBFS" || true
  fi
  if [[ "$hugetlbfs_dir_created_by_wrapper" -eq 1 ]]; then
    rmdir "$HUGETLBFS" 2>/dev/null || true
  fi
  driver="$(basename "$(readlink "/sys/bus/pci/devices/$BDF/driver")" 2>/dev/null)"
  netdev="$(current_netdev)"
  address="$(ip -4 -o addr show dev "$IFACE" 2>/dev/null || true)"
  hugepages="$(cat /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages 2>/dev/null)"
  carrier="$(cat "/sys/class/net/$IFACE/carrier" 2>/dev/null || true)"
  ping_ok=0
  ping_output="$(LC_ALL=C ping -q -I "$IFACE" -c 3 -W 1 20.1.1.1 2>/dev/null || true)"
  grep -Fq '3 packets transmitted, 3 received' <<<"$ping_output" && ping_ok=1
  vfio_holders="$(fuser "/dev/vfio/$GROUP" 2>/dev/null | xargs || true)"
  hugetlbfs_current="$(findmnt -rn --mountpoint "$HUGETLBFS" \
    -o FSTYPE,TARGET,SOURCE,OPTIONS 2>/dev/null || true)"
  [[ "$driver" = sfc ]] || restore_ok=0
  [[ "$netdev" = "$IFACE" ]] || restore_ok=0
  grep -Fq " $ADDR " <<<"$address" || restore_ok=0
  [[ "$hugepages" = 0 && "$carrier" = 1 && "$ping_ok" = 1 ]] || restore_ok=0
  [[ -z "$vfio_holders" ]] || restore_ok=0
  [[ "$hugetlbfs_current" = "$HUGETLBFS_BASELINE" ]] || restore_ok=0
  if [[ "$restore_ok" -ne 1 && "$final_rc" -eq 0 ]]; then final_rc=1; fi
  {
    echo '=== restore ==='
    echo "driver=$driver"
    echo "netdev=$netdev"
    printf '%s\n' "$address"
    echo "hugepages=$hugepages carrier=$carrier ping_ok=$ping_ok vfio_holders=${vfio_holders:-0}"
    echo "hugetlbfs_baseline=${HUGETLBFS_BASELINE:-ABSENT}"
    echo "hugetlbfs_final=${hugetlbfs_current:-ABSENT}"
    echo "restore_state=$([[ "$restore_ok" -eq 1 ]] && echo PASS || echo FAIL)"
  } | tee "$SESSION_DIR/restore.receipt"
  {
    echo "wrapper_exit_status=$final_rc"
    echo "trader_exit_status=$trader_exit_status"
    echo "cleanup_trader_exit_status=$cleanup_trader_rc"
    echo "restore_state=$([[ "$restore_ok" -eq 1 ]] && echo PASS || echo FAIL)"
  } >"$SESSION_DIR/gate-exit.receipt"
  return "$final_rc"
}
finish() {
  local wrapper_rc=$? final_rc
  trap - EXIT
  if restore "$wrapper_rc"; then final_rc=0; else final_rc=$?; fi
  exit "$final_rc"
}
trap finish EXIT

echo '=== preflight ==='
command -v findmnt mountpoint fuser >/dev/null
test "$(hostname)" = "$EXPECTED_HOST"
test -x "$BINARY"
test -x "$DPDK_DEVBIND"
test -r "$CONFIG"
test "$(basename "$(readlink "/sys/bus/pci/devices/$BDF/driver")")" = sfc
test "$(current_netdev)" = "$IFACE"
ip -4 -o addr show dev "$IFACE" | grep -Fq " $ADDR "
test "$(basename "$(readlink -f "/sys/bus/pci/devices/$BDF/iommu_group")")" = "$GROUP"
mapfile -t group_devices < <(find "/sys/kernel/iommu_groups/$GROUP/devices" \
  -mindepth 1 -maxdepth 1 -printf '%f\n')
test "${#group_devices[@]}" -eq 1
test "${group_devices[0]}" = "$BDF"
test "$(cat /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages)" = 0
modprobe vfio-pci
test "$(cat /sys/module/vfio/parameters/enable_unsafe_noiommu_mode)" = N
printf 'driver=sfc group=%s group_device=%s unsafe_noiommu=N\n' \
  "$GROUP" "${group_devices[0]}"
printf 'hugetlbfs_baseline=%s\n' "${HUGETLBFS_BASELINE:-ABSENT}"

echo '=== acquire X2522 with safe VFIO ==='
sysctl -w vm.nr_hugepages=256
test "$(cat /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages)" = 256
if [[ -z "$HUGETLBFS_BASELINE" ]]; then
  if [[ ! -d "$HUGETLBFS" ]]; then
    mkdir "$HUGETLBFS"
    hugetlbfs_dir_created_by_wrapper=1
  fi
  mount -t hugetlbfs nodev "$HUGETLBFS"
  hugetlbfs_mounted_by_wrapper=1
fi
ip link set "$IFACE" down
"$DPDK_DEVBIND" --bind=vfio-pci "$BDF"
test "$(basename "$(readlink "/sys/bus/pci/devices/$BDF/driver")")" = vfio-pci
rm -f "$STOP_FILE"

echo '=== start DPDK/F-Stack OUCH client ==='
env FLLE_MANAGEMENT_PORT=48125 FLLE_TELEMETRY_HOST=10.1.1.101 \
  FLLE_DPDK_HELPER_CPU=3 \
  FLLE_DPDK_USER_REF_BASE="$USER_REF_BASE" \
  FLLE_DPDK_USER_REF_SPAN="$USER_REF_SPAN" \
  taskset -c 2,3 "$BINARY" --conf "$CONFIG" --proc-type=primary --proc-id=0 \
  >"$SESSION_DIR/fstack.log" 2>&1 &
trader_pid=$!
echo "trader_pid=$trader_pid"
printf '%s\n' "$trader_pid" >"$SESSION_DIR/trader.pid"

ready=0
for _ in $(seq 1 80); do
  require_trader_alive
  state="$(timeout 1 bash -c 'exec 3<>/dev/tcp/10.1.1.2/48125; printf "STATE\n" >&3; IFS= read -r line <&3; printf "%s" "$line"' 2>/dev/null || true)"
  if [[ "$state" == *'"status":"ONLINE"'* &&
        "$state" == *'"order_transport":"DPDK_FSTACK"'* &&
        "$state" == *'"queue_mode":"DEQUE_CV"'* &&
        "$state" == *'"user_ref_base":'"$USER_REF_BASE"','* &&
        "$state" == *'"user_ref_span":'"$USER_REF_SPAN"','* ]]; then
    printf '%s\n' "$state" >"$SESSION_DIR/ready-state.json"
    ready=1
    break
  fi
  sleep 0.25
done
test "$ready" -eq 1
grep -Fq 'Using IOMMU type 1' "$SESSION_DIR/fstack.log"
grep -Fq 'Probe PCI driver: net_sfc_efx' "$SESSION_DIR/fstack.log"
grep -Fq 'running FW variant is ultra-low-latency' "$SESSION_DIR/fstack.log"
printf 'DPDK_TRADER_READY slot=%s user_ref_base=%s user_ref_span=%s\n' \
  "$USER_REF_SLOT" "$USER_REF_BASE" "$USER_REF_SPAN"

for ((second=0; second<DEADMAN; second++)); do
  [[ -f "$STOP_FILE" ]] && break
  require_trader_alive
  sleep 1
done
[[ -f "$STOP_FILE" ]] || { echo deadman_expired=1; exit 124; }
echo DPDK_TRADER_STOP_REQUESTED
if wait_for_trader_exit 1; then
  cleanup_line='cleanup_mode=PROCESS_EXIT_BYPASS_INCOMPLETE_FSTACK_CLEANUP shutdown_rc=0 peer_eof=1'
  test "$(grep -Fxc "$cleanup_line" "$SESSION_DIR/fstack.log")" -eq 1
  trader_cleanup_mode=PROCESS_EXIT_BYPASS_INCOMPLETE_FSTACK_CLEANUP
  trader_shutdown_rc=0
  trader_peer_eof=1
  record_trader_exit
  echo 'DPDK_TRADER_STOPPED status=0'
else
  trader_rc=$?
  echo "DPDK_TRADER_STOP_FAILED status=$trader_rc" >&2
  exit "$trader_rc"
fi
