# F-Stack / DPDK X2522 build contracts

The application pins F-Stack commit
`0abb713721a6a0ba95768acde052dbd3d2fdf3fe`. Its source tree contains DPDK
`24.11.6`, and the persistent management host keeps that complete source plus
a relocatable DPDK-24 development cache under:

```text
artifacts/blobs/x2522/f-stack/0abb713-dpdk-24.11.6/
```

That cache passed a clean-directory link test, but it did not become the
Chapter 06 hardware runtime. The verified four-order-path runtime uses the
same F-Stack commit patched for Ubuntu Jammy DPDK `21.11.9`; this is the
version whose packaged `net_sfc_efx` PMD completed a real X2522 order.

## Verified course runtime

The current distributable is:

```text
artifacts/blobs/x2522/ch06-four-path/v3/
  flle-ch06-four-path-v3-x86_64-jammy-runtime.tgz
```

Its SHA-256 is
`04dda25cc600201f540f6e227389eb9caeb6cab5f05be111c3e7ac8fc180c454`.
It contains the Socket, TCPDirect and F-Stack/DPDK traders, `zf_stackdump`,
`dpdk-devbind.py`, the F-Stack configuration and 26 resolved non-glibc shared
libraries. Verify both the outer artifact and its inner `MANIFEST.sha256`
before use.

The packaged F-Stack configuration is checked against
`third_party/fstack/f-stack-x2522.audit`. The latency profile keeps the
F-Stack reactor on CPU 2 with `idle_sleep=0` and `pkt_tx_delay=0`, moves the
bridge and management threads to CPU 3, and verifies `TCP_NODELAY` at runtime.
Application queues remain `DEQUE_CV`; only the network reactors poll.
The v3 clients also use the same timer boundary: OUCH is encoded, but Soup
framing and Transport work have not started. POSIX/F-Stack clients verify
`TCP_NODELAY` with `getsockopt`; the ZF API reports that POSIX switch as N/A.

The DPDK-21 compatibility patch is tracked at
`third_party/fstack/dpdk-21.11-compat.patch`. It handles the ethdev capability,
bonding-name and timer API differences between the pinned F-Stack source and
DPDK 21.11. F-Stack builds serially against the distro `libdpdk.pc`, and the
application links through the top-level `Makefile` with
`FSTACK_TREE=<patched-source>`.

The live acceptance contract is stronger than a link check:

- EAL reports `Using IOMMU type 1`;
- the PCI probe reports `net_sfc_efx` for `0000:03:00.0`;
- the PMD reports the ultra-low-latency firmware variant;
- `flle-trader-dpdk` completes a SoupBinTCP/OUCH fill;
- cleanup restores `sfc`, `20.1.1.2/24` and hugepages `0`.

These conditions, plus 12 files of 1000 executed orders and final restoration,
were met by preflight RUN `20260901T044247Z-06-four-path-preflight` and formal
RUN `20260901T044532Z-06-four-path-orders`. The v1 and v2 runtimes remain
registered as historical evidence; neither is the current classroom package.

## Optional DPDK-24 development cache

The DPDK-24 cache is an optimization, not the Chapter 06 source of truth.
Verify `artifacts/SHA256SUMS` before copying it to a guest. If its OS,
architecture, compiler ISA or external libraries do not match, rebuild it
from the source archive with the following contract.

### Fixed build inputs

- OS / architecture: Ubuntu 22.04, `x86_64`
- compiler: GCC 11.4.0
- DPDK: `24.11.6`, native ISA, tests and applications disabled
- DPDK drivers: `common/sfc_efx`, `net/sfc`, and `net/bonding`
- F-Stack: serial build with `CONF_CFLAGS=-Wno-error=array-bounds`

`net/bonding` is a compile dependency because this F-Stack revision includes
`rte_eth_bond.h` unconditionally. The FLLE runtime does not create a bond; a
hardware receipt must still identify the X2522 `net_sfc` PMD.

### DPDK-24 rebuild sequence

Assume `SRC`, `DPDK_BUILD`, and `PREFIX` are new absolute directories owned by
this build. Do not reuse `/usr/local` or the distro DPDK installation.

```bash
meson setup "$DPDK_BUILD" "$SRC/dpdk" --prefix="$PREFIX" \
  -Dplatform=native -Dtests=false -Denable_kmods=false \
  -Ddisable_apps='*' \
  -Denable_drivers=common/sfc_efx,net/sfc,net/bonding
meson compile -C "$DPDK_BUILD" -j4
meson install -C "$DPDK_BUILD"

export PKG_CONFIG_PATH="$PREFIX/lib/x86_64-linux-gnu/pkgconfig"
make -C "$SRC/lib" clean
make -C "$SRC/lib" CONF_CFLAGS=-Wno-error=array-bounds
make -C "$SRC/lib" install PREFIX="$PREFIX" \
  F-STACK_CONF="$PREFIX/f-stack.conf.example"
```

Do not add `-j` to the F-Stack library build. Its `machine_includes` target
deletes and recreates a header tree without ordering it before parallel object
compilation; a parallel build can intermittently fail with missing
`x86/endian.h`.

### DPDK-24 cached outputs

| Output | SHA-256 |
|---|---|
| `lib/libfstack.a` | `7290cfaad8b8906efd8cc8d0348c3fd1c9f0cc77013ba62e10661e4ac6fc17d7` |
| `lib/x86_64-linux-gnu/librte_net_sfc.a` | `021368139c034c281c96005fc3530ae3185bf02354831e7e1c855d0f819457ef` |

The optional cache rewrites every packaged `.pc` file to use
`prefix=${pcfiledir}/../../..`. Its acceptance check extracts it into a new
directory and links `echo_client_fstack.c` from that relocated prefix. This
only proves that the DPDK-24 development cache is portable and link-complete;
it must not be cited as the runtime used by the course result.
